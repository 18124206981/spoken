$(function(){
    //初始化动画
    new WOW().init();

    //返回顶部
    $(window).scroll(function () {
        if ($(window).scrollTop() >= 100) {
            $('.actGotop').fadeIn(300);
        } else {
            $('.actGotop').fadeOut(300);
        }
    });
    $('.actGotop').click(function () { $('html,body').animate({ scrollTop: '0px' }, 800); });
});

